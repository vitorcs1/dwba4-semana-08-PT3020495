class Aluno{
  
constructor(primeiroNome, segundoNome, primeiraNota, segundaNota){
  this.primeiroNome = primeiroNome
  this.segundoNome = segundoNome
  this.primeiraNota = primeiraNota
  this.segundaNota = segundaNota
}

  nomeCompleto(){
    var nomeCompleto = this.primeiroNome + " " + this.segundoNome

    alert(nomeCompleto)
  }

  media(){
    var mult1 = this.primeiraNota * 0.6
    var mult2 = this.segundaNota * 0.4
    var soma = mult1 + mult2
    
    alert(mult1 + " e " + mult2)
  }

  situacao(soma){

    var mult1 = this.primeiraNota * 0.6
    var mult2 = this.segundaNota * 0.4
    var soma = mult1 + mult2
    
    if(soma > 6){
      alert("Aprovado")
    }
    else{
      alert("Reprovado")
    }
  }
}

const a1 = new Aluno("Vitor", "Cardoso", 10, 10)
const a2 = new Aluno("Gustavo", "Oliveira", 5, 6)
const a3 = new Aluno("Eduardo", "Ferrari", 1, 2)
const a4 = new Aluno("Cleber", "Pirone", 2, 3)
const a5 = new Aluno("Pedro", "Barauna", 5, 8)

const arrayAlunos = [a1, a2, a3, a4, a5]

for(var i = 0; i<5; i++){
  arrayAlunos[i].nomeCompleto()
  arrayAlunos[i].media()
  arrayAlunos[i].situacao()
}