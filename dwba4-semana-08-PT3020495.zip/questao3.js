var nome = ["João da silva", "Pedro", "Eduardo"]
var nota1 = [7, 5, 2]
var nota2 = [1, 6, 10]

for(var i = 0; i<3; i++){

  var nomeAluno = nome[i]  

  var mult1 = nota1[i] * 0.6
  var mult2 = nota2[i] * 0.4

  var soma = mult1 + mult2
  
  alert("Nome do Aluno: " + nomeAluno + "\nNota: " + nota1[i] + "\nNota: " + nota2[i])
  alert("Nome do Aluno: " + nomeAluno + "\nNota final: " + soma)
}